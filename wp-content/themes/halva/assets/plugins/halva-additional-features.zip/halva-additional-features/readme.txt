=== Halva Additional Features ===
Contributors: Alexey Trofimov
Tags: widget, widgets, list-of-posts, popular-posts, random-posts, recent-posts, social, counters, cookies
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 1.1
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin provides a set of additional features for the Halva theme. This set includes the following features: 5 additional widgets, views counter, and a notification with information about cookies on the site.

== Changelog ==

= 1.1 =
* Added the X icon instead of the Twitter icon (Widget: "Halva: Social Links");
* Updated translation file (/halva-additional-features/languages/halva-additional-features.pot).

= 1.0 =
* Release.
